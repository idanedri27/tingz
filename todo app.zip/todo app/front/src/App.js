import { Provider } from "./Context";
import Form from "./components/Form";
import TodoList from "./components/TodoList";
import { Actions } from "./Actions";
import './App.css';



function App() {
  const data = Actions();
  return (
    <Provider value={data}>
      <div className="App">
        <h1>Todo App List</h1>
        <div className="wrapper">
          <section className="left-side">
            <Form />
          </section>
        </div>
        <section className="right-side">
            <TodoList />
        </section>
      </div>
    </Provider>
  );
}

export default App;