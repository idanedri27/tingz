import { useState, useContext } from "react";
import { AppContext } from "../Context";
const Form = () => {
  const { insertTodo } = useContext(AppContext);
  const [newTodo, setnewTodo] = useState({});

  // Storing the Insert todo Form Data.
  const addnewTodo = (e, field) => {
    setnewTodo({
      ...newTodo,
      [field]: e.target.value,
    });
  };

  // Inserting a new todo into the Database.
  const submitTodo = (e) => {
    e.preventDefault();
    insertTodo({...newTodo , completed : 0 });
    e.target.reset();
  };

  return (
    <form className="insertForm" onSubmit={submitTodo}>
      <input
        type="text"
        id="_name"
        onChange={(e) => addnewTodo(e, "content")}
        placeholder="Enter todo"
        autoComplete="off"
        required
      />
      <input type="submit" value="Add" />
    </form>
  );
};

export default Form;