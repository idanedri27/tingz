<?php

$db = 'todo-react-app';
$host= 'localhost';
$username = 'root';
$pass = '';

$db_conn = mysqli_connect($host,$username,$pass,$db);
if(!$db_conn){
    echo 'connected faild!';
}