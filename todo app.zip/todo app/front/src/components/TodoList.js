import { useContext, useState } from "react";
import { AppContext } from "../Context";

const TodoList = () => {
  const {
    todos,
    todoLength,
    editMode,
    cancelEdit,
    updateTodo,
    deleteTodo,
    doneTask,
  } = useContext(AppContext);

  // Storing todos new data when they editing their info.
  const [newData, setNewData] = useState({});

  const saveBtn = () => {
    updateTodo(newData);
  };

  const updateNewData = (e, field) => {
    setNewData({
      ...newData,
      [field]: e.target.value,
    });
  };

  const enableEdit = (id, content, completed) => {
    setNewData({ id, content, completed });
    editMode(id);
  };

  const deleteConfirm = (id) => {
    if (window.confirm("Are you sure?")) {
      deleteTodo(id);
    }
  };



  return !todoLength ? (
    <p>{todoLength === null ? "Please insert some todos." : ""}</p>
  ) : (
    <table>
      <thead>
        <tr>
          <th>todo</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        {todos.map(({ id, content, completed, isEditing, isDone }) => {
          return isEditing === true ? (
            <tr key={id}>
              <td>
                <input
                  type="text"
                  defaultValue={content}
                  onChange={(e) => updateNewData(e, "content")}
                />
              </td>
              <td>
                <button className="btn green-btn" onClick={() => saveBtn()}>
                  Save
                </button>
                <button
                  className="btn default-btn"
                  onClick={() => cancelEdit(id)}
                >
                  Cancel
                </button>
              </td>
            </tr>
          ) : (
            <tr key={id}>
              <td style={{textDecoration: isDone ? 'line-through' : 'none'}}>{content} </td>
              <td>
                <button
                  className="btn default-btn"
                  onClick={() => enableEdit(id, content, completed)}
                >
                  Edit
                </button>
                <button
                  className="btn red-btn"
                  onClick={() => deleteConfirm(id)}
                >
                  Delete
                </button>
                <button
                  className="btn success-btn"
                  onClick={() => doneTask(id , isDone)}
                >
                  Done
                </button>
              </td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
};

export default TodoList;