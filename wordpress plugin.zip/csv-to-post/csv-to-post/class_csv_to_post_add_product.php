<?php 

class CSVToPost{
    

    public  function CSVToPost_read_data($file_name ,$rows){
        
        $row = 0;
        $table = "<table>";
        $file = ABSPATH . 'wp-content/plugins/csv-to-post/'.$file_name.'.csv';
            if (($handle = fopen($file, "r")) !== FALSE) {
            
            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {

                
                $num = count($data);
                $table =  $table . "<tr>";
                $row++;

                if($rows[0] !== "all"){
                    for ($c=0; $c < $num; $c++) {
                        $active_row = $this->checkIfContainLine($rows , $row);
                        $column = substr($active_row,0,1);
                        $column = $this->cherecterToNumber($column);
                        
                        if($active_row){
                            $column = $column -1;
                            if($c ===$column){
                                $table = $table . '<td>' .$data[$column]. '</td>';
                            }
                        }
                    }
                }else{
                    for ($c=0; $c < $num; $c++) {
                        $table = $table . '<td>' .$data[$c]. '</td>';
                    }
                }
                
                $table  = $table . "</tr>";
                
            }
            $table = $table . "</table>";
            return $table;
        fclose($handle);
        }
        die();
    }

    function checkIfContainLine($rows , $string){
        foreach ($rows as $row) {
            $line_number = strval($string);         
            if (strpos( $row , $line_number ) !== false) {
                // var_dump($row);
                // var_dump($line_number);
                return $row;
            }
        }
    }

    function cherecterToNumber($dest){
        if ($dest)
            return ord(strtolower($dest)) - 96;
        else
            return 0;
    }
};

     

?>