import { useEffect, useState } from "react";

export const Actions = () => {
  let [todos, setTodos] = useState([]);

    //todoLength is for showing the Data Loading message.
  let [todoLength, setTodoLength] = useState(null);

  useEffect(() => {
    fetch("http://localhost/todo-react-php/getTodos.php")
      .then((res) => {
        return res.json();      
      })
      .then((data) => {
        if (data.success) {
          console.log(data.todo)
          setTodos(data.todo.reverse());
          setTodoLength(true);
        } else {
          setTodoLength(0);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  // Inserting a new todo into the database.
  const insertTodo = (newTodo) => {
    fetch("http://localhost/todo-react-php/createTodo.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(newTodo),
    })
      .then((res) => {
        return res.json();
      })
      .then((data) => {
        if (data.id) {
          setTodos([
            {
              id: data.id,
              ...newTodo,
            },
            ...todos,
          ]);
          setTodoLength(true);
        } else {
          alert('insert successfuly!');
          window.location.reload();
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // Enabling the edit mode for a listed todo.
  const editMode = (id) => {
    todos = todos.map((todo) => {
      if (todo.id === id) {
        todo.isEditing = true;
        return todo;
      }
      todo.isEditing = false;
      return todo;
    });
    setTodos(todos);
  };

  // Cancel the edit mode.
  const cancelEdit = (id) => {
    todos = todos.map((todo) => {
      if (todo.id === id) {
        todo.isEditing = false;
        return todo;
      }
      return todo;
    });
    setTodos(todos);
  };

  // Updating a todo.
  const updateTodo = (todoData) => {
    fetch("http://localhost/todo-react-php/updateTodo.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(todoData),
    })
      .then((res) => {
        console.log(res)
        return res.json();
      })
      .then((data) => {
        if (data.success) {
          todos = todos.map((todo) => {
            if (todo.id === todoData.id) {
              todo.isEditing = false;
              todo.content = todoData.content;
              todo.completed = todoData.completed;
              return todo;
            }
            return todo;
          });
          setTodos(todos);
        } else {
          alert(data.msg);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // Deleting a todo.
  const deleteTodo = (theID) => {
      // filter outing the todo.
    let todoDeleted = todos.filter((todo) => {
      return todo.id !== theID;
    });
    fetch("http://localhost/todo-react-php/deleteTodo.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ id: theID }),
    })
      .then((res) => {
        return res.json();
      })
      .then((data) => {
        if (data.success) {
          setTodos(todoDeleted);
          if (todos.length === 1) {
            setTodoLength(0);
          }
        } else {
          alert(data.msg);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };


  const doneTask = (id, isDone) => {
    console.log(id)
    console.log(todos)
    const newTodos = todos.map(todo =>{
      if(todo.id === id){
        todo.isDone = !isDone;
      }
      return todo;
    });
    setTodos(newTodos);
  }

  return {
    todos,
    editMode,
    cancelEdit,
    updateTodo,
    insertTodo,
    deleteTodo,
    todoLength,
    doneTask,
  };
};