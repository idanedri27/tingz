<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require 'db.php';

$sql = "SELECT * FROM `todos`";
$allTodos = mysqli_query($db_conn, $sql);
if (mysqli_num_rows($allTodos) > 0) {
    $all_todo = mysqli_fetch_all($allTodos, MYSQLI_ASSOC);
    echo json_encode(["success" => 1, "todo" => $all_todo]);
} else {
    echo json_encode(["success" => 0]);
}