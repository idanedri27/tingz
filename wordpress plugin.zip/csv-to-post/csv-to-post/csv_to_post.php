<?php
   /*
   Plugin Name: CSV to Posts
   Plugin URI: http://my-awesomeness-emporium.com
   description: import csv data to posts by shortcodes
 
   Version: 0.0.1
   Author: Idan Edri
   Author URI: https://swipesells.com
   License: GPL2
   */


  if(!defined('ABSPATH')){die('-1');}

 
  function CSVToPost_init(){
    require plugin_dir_path( __FILE__ ).'class_csv_to_post_add_product.php';
  }
  CSVToPost_init();
  
  // examples
  // [Sheet1]
  // [Sheet1 rows='a2, c2']
  // [Sheet1 rows='a2, a4,c3' file='2']

  function cav_data_shortcode( $atts ) {
      $CSVToPost = new CSVToPost;
      $a = shortcode_atts( array(
        'file' => '1',
        'rows' => 'all'
      ), $atts );

  
      $no_whitespaces = preg_replace( '/\s*,\s*/', ',', filter_var( $a['rows'], FILTER_SANITIZE_STRING ) ); 
      $rows_array = explode( ',', $no_whitespaces );
      $file_name = $a["file"];
  
      ob_start();
      $table = $CSVToPost->CSVToPost_read_data($file_name , $rows_array);
      echo $table;
      return ob_get_clean();
  }


  add_shortcode( 'Sheet1', 'cav_data_shortcode' );
  
  
?>